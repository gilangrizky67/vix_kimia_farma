select * 
from penjualan pe
left join pelanggan pl
on pe.id_customer = pl.id_customer 

select * from penjualantest p 

create table datamart_base as
select pe.*,pl.nama,pl.cabang_sales,pl.group,b.nama_barang
from penjualan pe
left join pelanggan pl
on pe.id_customer = pl.id_customer 
left join barang b
on pe.id_barang = b.kode_barang 


--Datamart Base--
create table datamart_base_kf as
select pe.id_invoice,pl.id_customer,b.kode_barang,pe.tanggal,pe.jumlah_barang,pe.harga,pl.nama,pl.cabang_sales,pl.group,b.nama_barang
from penjualan pe
left join pelanggan pl
on pe.id_customer = pl.id_customer 
left join barang b
on pe.id_barang = b.kode_barang 


--Data Mart Aggregate--
select b.nama_barang , sum(p.jumlah_barang) as jumlah_barang_terjual, sum(p.jumlah_barang * p.harga) as total_penjualan 
from penjualan p
left join barang b
on p.id_barang = b.kode_barang
order by total_penjualan desc



create table sales_by_cabang as
select cabang_sales, sum(jumlah_barang * harga) as total_penjualan 
from datamart_base_kf
group by cabang_sales 
order by total_penjualan desc

select * from sales_by_cabang sbc 

select * from datamart_base_kf dbk 

create table sales_by_day as
select TO_CHAR(tanggal, 'YYYY-MM-DD') AS formatted_date, sum(jumlah_barang) as jumlah_barang_terjual, sum(jumlah_barang * harga) as total_penjualan 
from datamart_base_kf dbk 
group by formatted_date
order by formatted_date

create table sales_by_barang as
select nama_barang , sum(jumlah_barang) as jumlah_barang_terjual, sum(jumlah_barang * harga) as total_penjualan 
from datamart_base_kf dbk 
group by nama_barang 
order by total_penjualan desc

create table comparison_between_group as
select  dbk.group, sum(jumlah_barang) as jumlah_barang_terjual, sum(jumlah_barang * harga) as total_penjualan,
round((SUM(jumlah_barang) * 100.0 / (SELECT SUM(jumlah_barang) FROM datamart_base_kf)),2) AS percentage
from datamart_base_kf dbk 
group by dbk.group
order by total_penjualan desc





